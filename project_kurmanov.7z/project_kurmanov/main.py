a = input()
b = 0
for i in range(a.__len__()):
    if a[i]=="a" or a[i]=="b" or a[i]=="0":
        b += 1
print(b)
